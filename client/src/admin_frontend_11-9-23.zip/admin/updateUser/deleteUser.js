//import axios from 'axios';
import React,{useState} from 'react';
import { useNavigate } from 'react-router-dom';
//import Navbar from '../../component/Navbar';

const Deleteuser = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    id: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };


  const handleDelete = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch('http://localhost:5000/api/delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.status === 200) {
        console.log('Delete successful');
        navigate('/user');
      } else {
        console.error('Delete failed');
      }
    } catch (error) {
      console.error('An error occurred', error);
    }
  };

  return (
    <div>
      {/* <Navbar/> */}
      <form>
  <input type="text" name="useridn" class="form-control" onChange={handleChange} placeholder="User ID" />
  <button onClick={handleDelete} class="btn btn-danger">Delete User</button>
</form>

    </div>
  )
}

export default Deleteuser;
