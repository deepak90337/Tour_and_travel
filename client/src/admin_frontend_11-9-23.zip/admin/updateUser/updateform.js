import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
//import Navbar from '../../component/Navbar';

const UserUpdate = () => {
  const [user, setUser] = useState({});
 // const [errors, setErrors] = useState("");

  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();
  

    const userID = event.target.userID.value;
    const updatedUser = {
      ...user,
      ...Object.keys(event.target).filter((key) => key !== 'submit').map((name) => event.target[name].value)
    };
  
    try {
      await axios.post(`http://localhost:5000/api/test/${userID}`, updatedUser);
     // await axios.post(`/api/test/${user.id}`, updatedUser);
      setUser(updatedUser);
      navigate('/user');
    } catch (error) {
      //setErrors(error.response.data.errors);
    }
  };
  

  return (
    <div>
      {/* <Navbar/> */}
      <h1>Update User</h1>
      <form onSubmit={handleSubmit}>
  <input type="text" name="userID" class="form-control" placeholder="User ID" />
  <input type="text" name="name" class="form-control" placeholder="Name" />
  <input type="email" name="email" class="form-control" placeholder="Email" />
  <input type="password" name="password" class="form-control" placeholder="Password" />
  <input type="password" name="cpassword" class="form-control" placeholder="Confirm Password" />
  <button type="submit" class="btn btn-primary">Update user</button>
  
  </form>
      {/* {errors.map((error) => (
        <p key={error}>{error}</p>
      ))} */}
    </div>
  );
};

export default UserUpdate;
