import React, { useState, useEffect } from 'react';
import UpdateForm from './updateUser/updateform';
import Navbar from '../component/Navbar';
import { Button} from "react-bootstrap";
import {  useNavigate } from 'react-router-dom';
//import Select from 'react-bootstrap-select';
//import {input} from 'react-bootstrap-input';
//import Deleteuser from './updateUser/deleteUser';

export default function User(){
//  const [ setSelectedUser] = useState("abc1");
//   const [setShowUpdateForm] = useState(false);
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserPhone, setNewUserPhone] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('');
  const [newUserCPassword, setNewUserCPassword] = useState('');
  const [newUserRole, setNewUserRole] = useState('user');

 const [isUpdateFormVisible, setIsUpdateFormVisible] = useState(false);
 const toggleUpdateForm = () => {
  navigate("/userupdate")
   setIsUpdateFormVisible(!isUpdateFormVisible);
};
 isUpdateFormVisible && (
        <div className="login-form-overlay">
          <div className="login-form">
            <UpdateForm/>
            <button
            style={{ color: 'black' }}
              className="btn btn-outline-danger"
              onClick={toggleUpdateForm}
            >
              Close
            </button>
          </div>
        </div>
      )

const redirectDelete = () =>{
  navigate("/delete");
}
  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/users'); // Change this URL to your API endpoint
      const data = await response.json();
      setUsers(data);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const handleNameChange = (event) => {
    setNewUserName(event.target.value);
  };

  const handleEmailChange = (event) => {
    setNewUserEmail(event.target.value);
  };

  const handlePhoneChange = (event) => {
    setNewUserPhone(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setNewUserPassword(event.target.value);
  };

  const handleCPasswordChange = (event) => {
    setNewUserCPassword(event.target.value);
  };

  // const handleRoleChange = (event) => {
  //   setNewUserRole(event.target.value);
  // };

  const addUser = async () => {
    if (newUserName.trim() === '' || newUserEmail.trim() === '' || newUserPhone.trim() === '' ||
        newUserPassword.trim() === '' || newUserCPassword.trim() === '') {
      return;
    }

    if (newUserPassword !== newUserCPassword) {
      console.error('Passwords do not match');
      return;
    }

    const newUser = {
      name: newUserName,
      email: newUserEmail,
      phone: newUserPhone,
      password: newUserPassword,
      cpassword: newUserCPassword,
      role: newUserRole,
    };

    try {
      const response = await fetch('http://localhost:5000/api/addUser', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newUser),
      });

      if (response.ok) {
        await fetchUsers();
        setNewUserName('');
        setNewUserEmail('');
        setNewUserPhone('');
        setNewUserPassword('');
        setNewUserCPassword('');
        setNewUserRole('user');
      } else {
        console.error('Error adding user in function');
      }
    } catch (error) {
      console.error('Error adding user:', error);
    }
  };

 

  return (
    <>
        <Navbar/>
        <table className="table striped hover">
        <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            {/* <th>Phone</th>
            <th>Role</th> */}
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.name}>
              <td>{user._id}</td>
              <td>{user.name}</td>
              <td>{user.email}</td>
              {/* <td>{user.phone}</td> */}
              {/* <td>{user.role}</td> */}
              <td>
                <Button
                  variant="primary"
                onClick={toggleUpdateForm}
                >
                  Update
                </Button>
              </td>
              <td>
                <Button variant="danger" onClick={redirectDelete}>Remove</Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <h3>Add New User</h3>
      <div className="container">
        <div className="row">
          <div className="col-md-6">
            <input
              type="text"
              classNameName="form-control"
              placeholder="Name"
              value={newUserName}
              onChange={handleNameChange}
            />
          </div>
          <div className="col-md-6">
            <input
              type="email"
              classNameName="form-control"
              placeholder="Email"
              value={newUserEmail}
              onChange={handleEmailChange}
            />
          </div>
        </div>
        <div className="row">
          <div className="col-md-6">
            <input
              type="tel"
              classNameName="form-control"
              placeholder="Phone"
              value={newUserPhone}
              onChange={handlePhoneChange}
            />
          </div>
          <div className="col-md-6">
            <input
              type="password"
              classNameName="form-control"
              placeholder="Password"
              value={newUserPassword}
              onChange={handlePasswordChange}
            />
          
          </div>
          
          
        </div>
        <div className="row">
          <div className="col-md-6">
            <input
              type="password"
              classNameName="form-control"
              placeholder="Confirm Password"
              value={newUserCPassword}
              onChange={handleCPasswordChange}
            />
            
          </div>
          <div className="col-md-6">
        {/* <select value={newUserRole} onChange={handleRoleChange}>
          <option value="admin">Admin</option>
          <option value="user">User</option>
        </select> */}
      
             <Button variant="primary"  size="sm" onClick={addUser}>Add User</Button>
    
     </div>
          </div>
          
        {/* <UpdateForm user={} onCancel={} onUpdate={} /> */}
        {/* <UpdateForm user={selectedUser} onUpdate={handleUpdate}/> */}
  </div>
  </>
  );
          }
